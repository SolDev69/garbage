package net.minecraft.src;

public class MinecraftException extends Exception {
   public MinecraftException(String par1Str) {
      super(par1Str);
   }
}
