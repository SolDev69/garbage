package net.minecraft.src;

interface IEnchantmentModifier {
   void calculateModifier(Enchantment var1, int var2);
}
