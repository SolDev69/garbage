package net.minecraft.src;

import java.util.Random;

public class EnchantmentThorns extends Enchantment {
   public EnchantmentThorns(int par1, int par2) {
      super(par1, par2, EnumEnchantmentType.armor_torso);
      this.setName("thorns");
   }

   public int getMinEnchantability(int par1) {
      return 10 + 20 * (par1 - 1);
   }

   public int getMaxEnchantability(int par1) {
      return super.getMinEnchantability(par1) + 50;
   }

   public int getMaxLevel() {
      return 3;
   }

   public boolean canApply(ItemStack par1ItemStack) {
      return par1ItemStack.getItem() instanceof ItemArmor?true:super.canApply(par1ItemStack);
   }

   public static boolean func_92094_a(int par0, Random par1Random) {
      return par0 <= 0?false:par1Random.nextFloat() < 0.15F * (float)par0;
   }

   public static int func_92095_b(int par0, Random par1Random) {
      return par0 > 10?par0 - 10:1 + par1Random.nextInt(4);
   }

   public static void func_92096_a(Entity par0Entity, EntityLiving par1EntityLiving, Random par2Random) {
      int var3 = EnchantmentHelper.func_92098_i(par1EntityLiving);
      ItemStack var4 = EnchantmentHelper.func_92099_a(Enchantment.thorns, par1EntityLiving);
      if(func_92094_a(var3, par2Random)) {
         par0Entity.attackEntityFrom(DamageSource.causeThornsDamage(par1EntityLiving), func_92095_b(var3, par2Random));
         par0Entity.playSound("damage.thorns", 0.5F, 1.0F);
         if(var4 != null) {
            var4.damageItem(3, par1EntityLiving);
         }
      } else if(var4 != null) {
         var4.damageItem(1, par1EntityLiving);
      }
   }
}
