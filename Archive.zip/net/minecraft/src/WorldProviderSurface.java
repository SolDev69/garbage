package net.minecraft.src;

public class WorldProviderSurface extends WorldProvider {
   public String getDimensionName() {
      return "Overworld";
   }
}
