package net.minecraft.src;

public abstract class ComponentVillageRoadPiece extends ComponentVillage {
   protected ComponentVillageRoadPiece(ComponentVillageStartPiece par1ComponentVillageStartPiece, int par2) {
      super(par1ComponentVillageStartPiece, par2);
   }
}
