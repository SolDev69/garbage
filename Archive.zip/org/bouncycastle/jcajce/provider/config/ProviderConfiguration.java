package org.bouncycastle.jcajce.provider.config;

public interface ProviderConfiguration {
}
