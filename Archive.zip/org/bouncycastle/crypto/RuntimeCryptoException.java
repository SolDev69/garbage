package org.bouncycastle.crypto;

public class RuntimeCryptoException extends RuntimeException {
   public RuntimeCryptoException() {}

   public RuntimeCryptoException(String par1Str) {
      super(par1Str);
   }
}
