package org.bouncycastle.crypto;

public class DataLengthException extends RuntimeCryptoException {
   public DataLengthException() {}

   public DataLengthException(String par1Str) {
      super(par1Str);
   }
}
