package net.minecraft.client.gui;

public interface GuiYesNoCallback {
   void func_73878_a(boolean p_73878_1_, int p_73878_2_);
}
