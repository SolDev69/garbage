package net.minecraft.client.gui.recipebook;

import java.util.List;
import net.minecraft.item.crafting.IRecipe;

public interface IRecipeUpdateListener {
   void func_193001_a(List<IRecipe> p_193001_1_);
}
