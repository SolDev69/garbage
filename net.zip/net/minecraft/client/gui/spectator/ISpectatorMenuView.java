package net.minecraft.client.gui.spectator;

import java.util.List;
import net.minecraft.util.text.ITextComponent;

public interface ISpectatorMenuView {
   List<ISpectatorMenuObject> func_178669_a();

   ITextComponent func_178670_b();
}
