package net.minecraft.client.util;

import java.util.List;

public interface ISearchTree<T> {
   List<T> func_194038_a(String p_194038_1_);
}
