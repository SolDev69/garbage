package net.minecraft.client.resources;

public interface IResourceManagerReloadListener {
   void func_110549_a(IResourceManager p_110549_1_);
}
