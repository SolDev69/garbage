package net.minecraft.client.renderer.color;

import net.minecraft.item.ItemStack;

public interface IItemColor {
   int func_186726_a(ItemStack p_186726_1_, int p_186726_2_);
}
