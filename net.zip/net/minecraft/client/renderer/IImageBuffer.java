package net.minecraft.client.renderer;

import java.awt.image.BufferedImage;

public interface IImageBuffer {
   BufferedImage func_78432_a(BufferedImage p_78432_1_);

   void func_152634_a();
}
