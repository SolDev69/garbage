package net.minecraft.client.renderer.texture;

public interface ITextureMapPopulator {
   void func_177059_a(TextureMap p_177059_1_);
}
