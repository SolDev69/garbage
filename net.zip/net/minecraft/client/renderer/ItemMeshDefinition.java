package net.minecraft.client.renderer;

import net.minecraft.client.renderer.block.model.ModelResourceLocation;
import net.minecraft.item.ItemStack;

public interface ItemMeshDefinition {
   ModelResourceLocation func_178113_a(ItemStack p_178113_1_);
}
