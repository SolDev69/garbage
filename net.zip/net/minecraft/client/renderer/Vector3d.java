package net.minecraft.client.renderer;

public class Vector3d {
   public double field_181059_a;
   public double field_181060_b;
   public double field_181061_c;
}
